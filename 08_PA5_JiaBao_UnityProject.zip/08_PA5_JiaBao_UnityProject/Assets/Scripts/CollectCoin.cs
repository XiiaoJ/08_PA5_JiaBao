﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class CollectCoin : MonoBehaviour
{
    public int score;
    public Text scoreBoxText;

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.tag == "Coin")
        {   
            Destroy(collision.gameObject);
            addScore();
        }
    }

    void addScore()
    {
        score+=5;
        scoreBoxText.text = "Score: "+ score.ToString();

        if (score >= 20)
        {
            SceneManager.LoadScene(1);
        }
    }
}
